const PRODUCTS = [
  {
    id: 1,
    name: "LED Sunset Lamp",
    image: "https://via.placeholder.com/600x600?text=Product+1",
    price: "$12.99",
    affiliateLink: "https://amzn.to/4oy5alK",
    outOfStock: false,
    description: "Viral aesthetic lamp for TikTok rooms."
  },
  {id:2,name:"Product 2",image:"https://via.placeholder.com/600x600?text=Product+2",price:"—",affiliateLink:"",outOfStock:false,description:""},
  {id:3,name:"Product 3",image:"https://via.placeholder.com/600x600?text=Product+3",price:"—",affiliateLink:"",outOfStock:false,description:""},
  {id:4,name:"Product 4",image:"https://via.placeholder.com/600x600?text=Product+4",price:"—",affiliateLink:"",outOfStock:false,description:""},
  {id:5,name:"Product 5",image:"https://via.placeholder.com/600x600?text=Product+5",price:"—",affiliateLink:"",outOfStock:false,description:""},
  {id:6,name:"Product 6",image:"https://via.placeholder.com/600x600?text=Product+6",price:"—",affiliateLink:"",outOfStock:false,description:""},
  {id:7,name:"Product 7",image:"https://via.placeholder.com/600x600?text=Product+7",price:"—",affiliateLink:"",outOfStock:false,description:""},
  {id:8,name:"Product 8",image:"https://via.placeholder.com/600x600?text=Product+8",price:"—",affiliateLink:"",outOfStock:false,description:""},
  {id:9,name:"Product 9",image:"https://via.placeholder.com/600x600?text=Product+9",price:"—",affiliateLink:"",outOfStock:false,description:""},
  {id:10,name:"Product 10",image:"https://via.placeholder.com/600x600?text=Product+10",price:"—",affiliateLink:"",outOfStock:false,description:""}
];