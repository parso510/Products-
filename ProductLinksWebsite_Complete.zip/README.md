# YourShopLinks

This is a simple product finder website that lets users search a number or click a button to view your affiliate products. Perfect for linking in TikTok or Instagram bios.

## How It Works

- Type a number (1–10) in the search bar or click a button
- The product card will appear with:
  - Image
  - Name
  - Price
  - Description
  - Buy Now button (affiliate link)
- Copy the affiliate link with the "Copy Link" button

## How to Add Your Products

1. Open `products.js`
2. Add your products like this:

```js
{
  id: 1,
  name: "LED Sunset Lamp",
  image: "https://example.com/lamp.jpg",
  price: "$12.99",
  affiliateLink: "https://amzn.to/abcd1234",
  outOfStock: false,
  description: "Viral aesthetic lamp for TikTok rooms."
}
```

3. Save and commit changes → your site updates automatically.

## Deployment

1. Create a public GitHub repository
2. Upload `index.html`, `style.css`, `products.js`, `script.js`
3. Go to **Settings → Pages** → select:
   - Branch: `main`
   - Folder: `/ (root)`
4. Click **Save** → your site will be live at:
```
https://YOUR-USERNAME.github.io/product-links/
```

## Notes

- Make sure `index.html` is in the root folder
- Use HTTPS image links for product images
- You can increase the number of products by adding more items in `products.js`
